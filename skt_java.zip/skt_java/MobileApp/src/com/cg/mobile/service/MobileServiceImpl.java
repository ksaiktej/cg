package com.cg.mobile.service;

import java.util.List;

import com.cg.mobile.bean.Customer;
import com.cg.mobile.bean.Mobile;
import com.cg.mobile.dao.MobileDaoImpl;
import com.cg.mobile.dao.iMobileDao;

public class MobileServiceImpl implements iMobileService{
	iMobileDao dao = new MobileDaoImpl();
	
	//@Override
	public String display(){
		return dao.display();
	}
	public List<Mobile> getMobileByPrice(double price){
		return dao.getMobileByPrice(price);
	}
	public List<Mobile> getAllMobiles(){
		return dao.getAllMobiles();
	}
	@Override
	public List<Mobile> delMobiles(int mobileId) {
		// TODO Auto-generated method stub
		return dao.delMobiles(mobileId);
	}
	@Override
	public boolean mob_availability(int mobileId) {
		// TODO Auto-generated method stub
		return dao.mob_availability(mobileId);
	}
	@Override
	public void insert_cust_details(Customer c) {
		// TODO Auto-generated method stub
		
	}

}
