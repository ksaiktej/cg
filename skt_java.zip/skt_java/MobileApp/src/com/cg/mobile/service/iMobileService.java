package com.cg.mobile.service;

import java.util.List;

import com.cg.mobile.bean.Customer;
import com.cg.mobile.bean.Mobile;

public interface iMobileService {
	public String display();
	public List<Mobile> getMobileByPrice(double price);
	public List<Mobile> getAllMobiles();
	public List<Mobile> delMobiles(int mobileId);
	public boolean mob_availability(int mobileId);
	public void insert_cust_details(Customer c);
	

	

}
