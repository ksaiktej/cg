package com.cg.mobile.ui;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.cg.mobile.bean.Customer;
import com.cg.mobile.bean.Mobile;
import com.cg.mobile.service.MobileServiceImpl;
import com.cg.mobile.service.iMobileService;

public class MobileUI {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		iMobileService service = new MobileServiceImpl();
		System.out.println(service.display());
		Scanner sc = new Scanner(System.in);
		while(true){
			System.out.println("1. insert");
			System.out.println("2. update");
			System.out.println("3. view");
			System.out.println("4. delete");
			System.out.println("5. search");
			System.out.println("6. exit");
			System.out.println("enter your option");
			int opt = sc.nextInt();
			switch(opt){
			case 1:
				System.out.println("enter mobileId you need");
				int id = sc.nextInt();
				if(!mob_availability(id)){
					break;
				}
				Customer c = new Customer();
				System.out.println("Mobile available");
				
				System.out.println("Enter customer");
				sc.nextLine();
				c.setName(sc.nextLine());
				System.out.println("Enter mail id");
				c.setMailId(sc.next());
				System.out.println("Enter phno");
				c.setPhoneno(sc.nextLong());
				c.setMobileId(id);
				insert_cust_details(c);
				
				
				
				break;
			case 2:
				break;
			case 3:
				List<Mobile> list1 = service.getAllMobiles();
				for(Mobile m: list1){
					System.out.println("id: "+m.getMobileId());
					System.out.println("name: "+m.getName());
					System.out.println("price: "+m.getPrice());
					System.out.println("quantity: "+m.getQuantity());
					System.out.println("--------------------------");
					}
				break;
			case 4:
				System.out.println("enter mobileId");
				int mobileId = sc.nextInt();
				System.out.println(mobileId);
				List<Mobile> list2 = service.delMobiles(mobileId);
				Iterator<Mobile> it = list2.iterator();
				Mobile m2 = null;
				while(it.hasNext()){
					m2 = it.next();
					System.out.println("id: "+m2.getMobileId());
					System.out.println("name: "+m2.getName());
					System.out.println("price: "+m2.getPrice());
					System.out.println("quantity: "+m2.getQuantity());
					System.out.println("--------------------------");		
				}
				
				break;
			case 5:
				System.out.println("enter price");
				double price = sc.nextDouble();
				List<Mobile> list = service.getMobileByPrice(price);
				Iterator<Mobile> it1 = list.iterator();
				Mobile m1 = null;
				while(it1.hasNext()){
					m1 = it1.next();
					System.out.println("id: "+m1.getMobileId());
					System.out.println("name: "+m1.getName());
					System.out.println("price: "+m1.getPrice());
					System.out.println("quantity: "+m1.getQuantity());
					System.out.println("--------------------------");
					
				}

			

				break;
			case 6:
				System.exit(0);
			}
			
		}
}
}
