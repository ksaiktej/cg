package com.cg.mobile.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.cg.mobile.bean.Customer;
import com.cg.mobile.bean.Mobile;

public class MobileDaoImpl implements iMobileDao {
	public String display(){
		return "demo for mobile app";
	}
	public List<Mobile> getMobileByPrice(double price){
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url = "jdbc:oracle:thin:@localhost:1521:XE";
			String user = "system";
			String pass = "Capgemini123";
			Connection con = DriverManager.getConnection(url,user,pass);
			String sql = "select * from mobiles where price>=?";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setDouble(1, price);
			ResultSet rs = ps.executeQuery();
			Mobile m = null;
			List<Mobile> list = new ArrayList<>();
			while(rs.next()){
				m = new Mobile();
				m.setMobileId(rs.getInt(1));
				m.setName(rs.getString(2));
				m.setPrice(rs.getDouble(3));
				m.setQuantity(rs.getString(4));
				list.add(m);
			}
			return list;
		}catch(Exception e){
			
		}
		return null;
		
	}
	public List<Mobile> getAllMobiles(){
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url = "jdbc:oracle:thin:@localhost:1521:XE";
			String user = "system";
			String pass = "Capgemini123";
			Connection con = DriverManager.getConnection(url,user,pass);
			String sql = "select * from mobiles";
			PreparedStatement ps = con.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			Mobile m = null;
			List<Mobile> list = new ArrayList<>();
			while(rs.next()){
				m = new Mobile();
				m.setMobileId(rs.getInt(1));
				m.setName(rs.getString(2));
				m.setPrice(rs.getDouble(3));
				m.setQuantity(rs.getString(4));
				list.add(m);
			}
			return list;
		}catch(Exception e){
			
		}
		return null;
		
	}
	@Override
	public List<Mobile> delMobiles(int mobileId) {
		// TODO Auto-generated method stub
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url = "jdbc:oracle:thin:@localhost:1521:XE";
			String user = "system";
			String pass = "Capgemini123";
			Connection con = DriverManager.getConnection(url,user,pass);
			String sql = "delete from mobiles where mobileId=?";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1, mobileId);
			ps.executeQuery();
			System.out.println("Succesfully deleted mobile id"+mobileId);
			System.out.println("---------Left Out Mobiles----------");
			String sql1 = "select * from mobiles";
			PreparedStatement ps1 = con.prepareStatement(sql1);
			ResultSet rs = ps1.executeQuery();
			Mobile m = null;
			List<Mobile> list = new ArrayList<>();
			while(rs.next()){
				m = new Mobile();
				m.setMobileId(rs.getInt(1));
				m.setName(rs.getString(2));
				m.setPrice(rs.getDouble(3));
				m.setQuantity(rs.getString(4));
				list.add(m);
			}
			return list;
		}catch(Exception e){
			
		}
		return null;
	}
	@Override
	public boolean mob_availability(int mobileId) {
		// TODO Auto-generated method stub
		boolean b;
		ResultSet rs = null;
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url = "jdbc:oracle:thin:@localhost:1521:XE";
			String user = "system";
			String pass = "Capgemini123";
			Connection con = DriverManager.getConnection(url,user,pass);
			String sql = "select quantity from mobiles where mobileId=?";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1, mobileId);
			try{
			rs =ps.executeQuery();
			}catch(Exception e){
				System.out.println("mobileId doesnot exist");
				return false;
			}
			rs.next();
			int q = rs.getInt(1);
			if(q<=0){
				System.out.println("Stock not available");
				return false;
			}
			else{
				return true;
			}
		}catch(Exception e){
			return false;
		}
	}
	@Override
	public void insert_cust_details(Customer c) {
		// TODO Auto-generated method stub
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url = "jdbc:oracle:thin:@localhost:1521:XE";
			String user = "system";
			String pass = "Capgemini123";
			Connection con = DriverManager.getConnection(url,user,pass);
			String sql = "insert into Customer values" +"(?,?,?,?)";
		}catch(Exception e){
			
		}
		
		
	}
		
			
			
		
		
		
	

}
