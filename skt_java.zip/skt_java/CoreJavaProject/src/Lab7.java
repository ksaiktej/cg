import java.util.*;
public class Lab7 {
	public static void main(String args[]){
		ArrayList<String> al = new ArrayList<String>();
		al.add("vineeth");
		al.add("dharma");
		al.add("sai");
		Iterator it = al.iterator();
		while(it.hasNext()){
			System.out.println(it.next());
		}
		System.out.println("array list is: "+al);
	}

}
