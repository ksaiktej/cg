package javaJDBC;
import java.sql.*;
public class OracleCon{

	
	public static void main(String[] args) throws ClassNotFoundException,SQLException {
		// TODO Auto-generated method stub
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521","system","Capgemini123");
		Statement st = con.createStatement();
		

	}

}
