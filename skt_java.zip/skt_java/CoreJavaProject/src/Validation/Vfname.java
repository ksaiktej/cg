package Validation;

import java.util.Scanner;
import java.util.regex.Pattern;

public class Vfname {
	void v_fname(String s) throws Inv_Fname_Exc{
		boolean b = Pattern.compile("[a-zA-Z]{6}").matcher(s).matches();
		if(b==true){
			System.out.println("first name matched");
		}
		else{
			//System.out.println("not a valid first name");
			throw new Inv_Fname_Exc("not a valid fname");
		}
		
		
	}
	
	void v_lname(String s) throws Inv_Lname_Exc{
		boolean b = Pattern.compile("[a-zA-Z]{6}").matcher(s).matches();
		if(b==true){
			System.out.println("last name matched");
		}
		else{
			throw new Inv_Lname_Exc("not a valid Last name");
		}
		
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("enter fname and lname");
		String fname = sc.nextLine();
		String lname = sc.nextLine();
		Vfname vf1 = new Vfname();
		try{
			vf1.v_fname(fname);
		}catch(Exception e){
			//e.printStackTrace();
			System.out.println(e);
		}
		try{
			vf1.v_lname(lname);
		}catch(Exception e){
			//e.printStackTrace();
			System.out.println("Error in Lname");
		}

	}

}
class Inv_Lname_Exc extends Exception{
	Inv_Lname_Exc(String s){
		super(s);
	}
}
class Inv_Fname_Exc extends Exception{
	Inv_Fname_Exc(String s){
		super(s);
	}
}

