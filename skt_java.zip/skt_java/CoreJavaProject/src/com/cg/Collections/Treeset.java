package com.cg.Collections;

import java.util.*;


public class Treeset {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SortedSet<String> ts = new TreeSet();
		ts.add("sai");
		ts.add("sushnath");
		ts.add("vineeth");
		ts.add("dharma");
		Iterator<String> it = ts.iterator();
		while(it.hasNext()){
			System.out.println(it.next());
		}

	}

}
