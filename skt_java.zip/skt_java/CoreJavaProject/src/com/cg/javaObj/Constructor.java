package com.cg.javaObj;

public class Constructor {
	Constructor(){
		
		this.display();
		System.out.println("hello");
	}
	void display(){
		System.out.println("world");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Constructor();
		

	}

}
