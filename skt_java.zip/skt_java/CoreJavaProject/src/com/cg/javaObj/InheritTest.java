package com.cg.javaObj;

public class InheritTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Child c = new Child2();
		c.m1();
		//p.m2();

	}

}
 class Parent{
	 public Parent() {
		// TODO Auto-generated constructor stub
		 System.out.println("Parent Constructor");
	}
	void m1(){
		System.out.println("parent");
	}
}
 class Child extends Parent{
	 public Child() {
		// TODO Auto-generated constructor stub
		 System.out.println("Child constructor");
	}
	void m2(){
		System.out.println("child");
	}
}
 class Child2 extends Child{
	 public Child2() {
		// TODO Auto-generated constructor stub
		 System.out.println("Child2 constructor");
	}
	 void m2(){
		 System.out.println("child2");
	 }
 }
