package com.cg.javaObj;
import java.util.Scanner;
public class Exec{

	public static void main(String args[]) throws Inv_ageException {
		// TODO Auto-generated method stub
		
		Scanner sc = new Scanner(System.in);
		try{
		int age = sc.nextInt();
		if(age<18){
			throw new Inv_ageException("age should be > 18");
		}
		else{
			System.out.println("ready");
		}
		//System.out.println("new code");
		
		}catch(Exception ae){
			System.out.println(ae+"age should be >18");
			System.out.println("cghode");
		}
		finally{
			System.out.println("finally executed");
		}
		System.out.println("rest of code");

}
}
class Inv_ageException extends Exception{
	Inv_ageException(String s){
		super(s);
		
	}
	
}

	
 