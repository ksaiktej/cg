package com.cg.javaObj;

import java.io.*;
class InvalidAgeException extends Exception{
	InvalidAgeException(String s){
		super(s);
	}
}
class Election {
	void age(int a) throws InvalidAgeException{
		if(a<18){
			throw new InvalidAgeException("not valid ");
		}else{
			System.out.println("ready to vote");
		}
		}
	
	public static void main(String args[]){
		Election el = new Election();
		try{
		el.age(14);
		}catch(Exception e){
			System.out.println(e+"handled");
		}
	}
}
