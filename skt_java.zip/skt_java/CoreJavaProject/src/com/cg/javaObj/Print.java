package com.cg.javaObj;

public class Print {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.print("he");
		System.out.println("llo");

	}

}
