package com.cg.javaObj;

public class Account {
	String name;
	double amount;
	void insert(String name,double amount){
		this.name=name;
		this.amount=amount;
	}
	void deposit(int d_amt){
		amount+=d_amt;
		//System.out.println(d_amt+" is deposited");
		check_bal();
		
	}
	void withdraw(int w_amt){
		amount-=w_amt;
		//System.out.println(w_amt+" is withdrawn");
		check_bal();
	}
	void check_bal(){
		System.out.println("Your remaining balance:"+amount);
	}
	public static void main(String args[]){
		Account a = new Account();
		a.insert("sai",0);
		a.deposit(17003);
		a.withdraw(14000);
		//a.check_bal();
		
	}

}
