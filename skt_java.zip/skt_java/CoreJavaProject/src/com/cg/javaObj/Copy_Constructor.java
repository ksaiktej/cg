package com.cg.javaObj;

public class Copy_Constructor {
	int id;
	String name;
	Copy_Constructor(int i,String nm){
		id=i;
		name=nm;
		
		
	}
	Copy_Constructor(Copy_Constructor c){
		id=c.id;
		name=c.name;
	}
	void display(){
		System.out.println("id:"+id+" name:"+name);
	}
	public static void main(String args[]){
		Copy_Constructor c = new Copy_Constructor(111,"sai krishna tej");
		Copy_Constructor c2 = new Copy_Constructor(c);
		c.display();
		c2.display();
	}
		

}
