/*package com.cg.javaObj;

public class Enum {
	enum day{Sunday,Monday,Tuesday}
	
	public static void main(String args[]){
		Scanner 
	System.out.println(day.Sunday);
	
	}

}*/
package com.cg.javaObj;
import java.util.Scanner;
//enum
enum Gender1 { 
M,F;
}
public class Lab2_5 {
String firstName;
String lastName;
Gender1 gender;
boolean gender1;
long phone;
//constructor
Lab2_5(){
System.out.println("Person Details:"+"\n--------------\n");
}
//parameterized constructor
Lab2_5(String fname, String lname, boolean gend) {
this();
firstName = fname;
lastName = lname;
if(gend==true) {
gender = Gender1.M;
}
else {
gender = Gender1.F;
}
}
//phone setter method
void setPhone(long a) {
phone = a;
}
//phone getter method
void getPhone() {
System.out.println("Phone: "+phone);
}
//getter method
void getMethod() {
System.out.println("First Name: "+firstName+"\nLast Name: "+lastName);
System.out.println("Gender: "+gender);
getPhone();
}
public static void main(String[] args) {
Scanner sc = new Scanner(System.in);
System.out.println("Enter values");
Lab2_5 Obj = new Lab2_5(sc.next(),sc.next(),sc.nextBoolean());
Obj.setPhone(1234567890);
Obj.getMethod();
sc.close();
}
}