package com.cg.javaObj;
import java.util.regex.*;
public class Regex1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Pattern p = Pattern.compile(".s");
		Matcher m = p.matcher(".s");
		boolean b = m.matches();
		//2nd way
		boolean b1 = Pattern.compile(".s").matcher("vs").matches();
		//3rd way
		boolean b2 = Pattern.matches("..ss", "mass"); // "." represents character
		boolean b3 = Pattern.matches("[a-z]", "v"); //[a-z] means only one character allowed
		boolean b4 = Pattern.matches("..[is].", "saik");
		boolean b5 = Pattern.matches("[a-z]?", "v"); // "?" only one from [..]
		boolean b6 = Pattern.matches("[anm]+", "ammnnn"); //"+" any no.of values in [..]
		boolean b7 = Pattern.matches("[anm]*", "annm");//any value zero or more times in [..]
		boolean b8 = Pattern.matches("[6-9]{1}[0-9]{9}", "7036407471"); //phno:
		boolean b9 = Pattern.matches("[789]{1}\\d{9}", "7123456789"); // {d} takes only digits
		//boolean b6 = Pattern.matches("[anm]+", "ammnnn");
		System.out.println(b);
		System.out.println(b1);
		System.out.println(b2);
		System.out.println(b3);
		System.out.println(b4);
		System.out.println(b5);
		System.out.println(b6);
		System.out.println(b7);
		System.out.println(b8);
		System.out.println(b9);
		//System.out.println(b7);

	}

}
