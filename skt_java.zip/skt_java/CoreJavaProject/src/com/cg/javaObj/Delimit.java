package com.cg.javaObj;

import java.util.Scanner;

public class Delimit {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner("1,2,3,4").useDelimiter(",");
		
		

	}

}
