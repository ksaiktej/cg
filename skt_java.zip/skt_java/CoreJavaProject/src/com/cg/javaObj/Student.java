package com.cg.javaObj;

public class Student {
	String name;
	int id;
	int score;
	void insert_Score(int i,String nm,int sc){
		id=i;
		name=nm;
		score=sc;
	}
	void result(){
		if(score>60){
			System.out.println("Congratulations "+ name+", utgot infosys");
		}
		else{
			System.out.println("fail");
		}
	}
	public static void main(String args[]){
		Student s1= new Student();
		s1.insert_Score(101,"Sai",75);
		s1.result();
	}

}
