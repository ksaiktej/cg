package com.cg.javaObj;

public class Wrap {
	public static void main(String args[]){
		
	
	int a =20;
	Integer b = Integer.valueOf(a);
	System.out.println(a+""+b);
	Integer c = new Integer(3);
	int d = c.intValue();
	System.out.println(c+""+d);
	
}

}
