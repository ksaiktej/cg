package com.cg.javaObj;
import static java.lang.Math.*;

public class Mathe {
	int n=900;
	public static void main(String args[]){
		Mathe m = new Mathe();
		System.out.printf("%.1f",sqrt(m.n));
	}
	

}
