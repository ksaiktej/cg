package com.cg.javaObj;

public class Conc {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringBuffer sb = new StringBuffer("welcome");
		
		String s1="sai";
		//Conc c = new Conc();
		s1=s1.concat(s1);
System.out.println(s1);
	}

}
