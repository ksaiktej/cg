package com.cg.javaObj;

public class Aggregate {
	Square sq;//Aggregate
	double r;
	//double area;
	double pi=3.14;
	double area(double r){
		sq = new Square();
		double rsquare = sq.square(r);
		return (rsquare*pi);
		
	}
	public static void main(String args[]){
		Aggregate ag = new Aggregate();
		System.out.println(ag.area(5));
		
	}
}
class Square{
	double square(double n){
		return n*n;
	}
	
}


