package com.cg.Asses1;

 class B {
	
	void print(){
		System.out.println("parent class");
		
	}
	
	
}
public class Polymorphism extends B{
	void print(){
		System.out.println("child class");
	}
	void print1(){
		System.out.println("second class");
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		B b1 = new Polymorphism();
		b1.print();
		b1.print1();
	}

}
