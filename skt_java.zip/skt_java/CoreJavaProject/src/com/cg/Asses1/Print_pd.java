package com.cg.Asses1;
import java.util.Scanner;

public class Print_pd {

	//@SuppressWarnings("resource")
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		String fname = sc.nextLine();
		String lname = sc.nextLine();
		String gen = sc.next();
		int age = sc.nextInt();
		double wt = sc.nextDouble();
		System.out.println("Personal Details:");
		System.out.println("____________________");
		System.out.println();
		System.out.println("First Name: "+fname);
		System.out.println("Last Name: "+lname);
		System.out.println("Gender: "+gen);
		System.out.println("Age: "+age);
		System.out.println("Weight: "+wt);
		

	}

}
