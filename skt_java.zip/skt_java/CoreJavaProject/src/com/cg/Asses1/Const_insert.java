package com.cg.Asses1;

public class Const_insert {
	void insert(){
		
	}

}
