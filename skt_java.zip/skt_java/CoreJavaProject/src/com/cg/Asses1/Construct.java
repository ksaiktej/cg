package com.cg.Asses1;
//import java.util.Scanner;
public class Construct {
	String fname,lname,gen;
	long phn;
	Construct(){
		System.out.println("Personal Details");
	}
	Construct(String fn,String ln,String g){
		this();
		fname = fn;
		lname = ln;
		gen = g;
		
	}
	void set_phn(long num){
		phn = num;
	}
	void display(){
		
		System.out.println("________________");
		System.out.println();
		System.out.println("first name: "+fname);
		System.out.println("Last Name: "+lname);
		System.out.println("gender: "+gen);
	}
	void upd_display(){
		
		this.display();
		System.out.println(phn);
	}
	public static void main(String args[]){
		//Scanner sc = new Scanner(System.in);
		
		Construct c = new Construct("sai","kotipalli","M");
		c.display();
		//System.out.println("Enter phone number");
		//long num = sc.nextLong();
		c.set_phn(703640747);
		c.upd_display();
		
		
	}
}
