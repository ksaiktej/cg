package com.cg.Asses1;
import java.util.Scanner;
public class Check_Val {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a;
		Scanner sc = new Scanner(System.in);
		a = sc.nextInt();
		if(a>0){
			System.out.println("Positive");
		}
		else if(a<0){
			System.out.println("Negative");
		}
		else{
			System.out.println("ZERO(neither positive nor Negative)");
		}

	}

}
