package com.cg.emp.ui;
import java.util.Scanner;
import java.util.Random;
public class Client {
	public static void main(String args[]){
		String ename,role,email;
		long phno;
		int sal;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your emp name:");
		ename = sc.nextLine();
		System.out.println("Enter your phno:");
		phno = sc.nextLong();
		System.out.println("enter role:");
		role = sc.next();
		System.out.println("Enter sal:");
		sal = sc.nextInt();
		System.out.println("enter email id:");
		email = sc.next();
		System.out.println("You have registered successfully");
		sc.close();
		
		
	}

}
