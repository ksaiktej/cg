package com.cg.operators;
public class Bitwise {

	public static void main(String[] args) {
		int a,b;
		a=10;
		b=5;
		System.out.println("a & b :"+(a&b));
		System.out.println("a | b :"+(a|b));

	}

}
