package com.cg.operators;
public class Company {
	String k="this is Parent";

	}
	class Class10 extends Company {
		public void view(Company c){
			if(c instanceof Class10){
				Class10 b1=(Class10)c;
				b1.check();
				System.out.println("Success"+k);
			}
		}
		public void check(){
			System.out.println("Success"+k);
		}
		public static void main(String[] args) {
			Class10 c = new Class10();
			Class10 d = new Class10();
			d.view(c);
	}

}
