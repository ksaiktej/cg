package com.cg.operators;

public class Relational {

	public static void main(String[] args) {
		int a=5;
		int b=8;
		if(b>a){
			System.out.println("b is greater than a");
		}
		
		else if(a>b){
			System.out.println("a is greater than b");
		}
		else{
			System.out.println("both are equal");
		}
		
		int d=a>b?a:b; //condition statement;
		System.out.print(d+" is greater");
		

	}

}
