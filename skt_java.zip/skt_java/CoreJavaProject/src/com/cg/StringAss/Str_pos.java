package com.cg.StringAss;
import java.util.Scanner;
import java.lang.String;
import java.lang.Character;

public class Str_pos {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1 = new String();
		int i;
		Scanner sc = new Scanner(System.in);
		s1 = sc.nextLine();
		char[] ch = s1.toCharArray();
		int val = (int)ch[0];
		for(i=1;i<s1.length();i++){
			if(Character.isLetter(ch[i])){
				
				if((int)ch[i]>=val){
					val = (int)ch[i];
				}
				else{
					System.out.println("negative");
					System.exit(0);
				}
			}
		}
		if(i==s1.length()+1){
			System.out.println("positive");
			
		}

	}

	

}
