package com.cg.StringAss;

public class Str {
	String add(String s1){
		String a_s;
		a_s = s1.concat(s1);
		
		return a_s;
	}
	void rep_str(String s1){
		//int i;
		//String d_s1;
		for(int i=0;i<s1.length();i++){
			if(i%2==0){
				System.out.print("#");
			}
			else{
				System.out.print(s1.charAt(i));
			}
		}
		}
	void rep_dup(String str){
		char[] c1 = str.toCharArray();
		for(int i=0;i<str.length();i++){
			for(int j=i+1;j<str.length();j++){
				if(c1[i]==c1[j]){
					c1[j]='\0';
				}
			}
		}
		 str = new String(c1);
		System.out.println(str);
		
	}
	void o_upper(String s1){
		//int i;
		//String d_s1;
		for(int i=0;i<s1.length();i++){
			char ch = s1.charAt(i);
			if(i%2==0){
				System.out.print(Character.toUpperCase(ch));
			}
			else{
				System.out.print(s1.charAt(i));
			}
		}
		}
		
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Str str1 = new Str();
		System.out.println(str1.add("sai"));
		str1.rep_str("saikrishnatej");
		str1.rep_dup("sushanth");
		str1.o_upper("saikrishnatej");

	}

}
