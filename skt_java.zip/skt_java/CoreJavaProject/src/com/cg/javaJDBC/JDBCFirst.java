package com.cg.javaJDBC;

import java.sql.*;

public class JDBCFirst {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		try{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		String url = "jdbc:oracle:thin:@localhost:1521:XE";
		Connection con = DriverManager.getConnection(url,"system","Capgemini123");
		Statement st = con.createStatement();
		ResultSet rs = st.executeQuery("select * from emp");
		while(rs.next()){
			System.out.println("empno:"+rs.getInt("empno"));
			System.out.println("empname :"+rs.getString("ename"));
		}
		}catch(Exception e){
			System.out.println(e);
		}

	}

}
