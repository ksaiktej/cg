import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;


public class DateFunction {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("enter date");
		Scanner sc = new Scanner(System.in);
		String date = sc.nextLine();
		LocalDate localDate =LocalDate.parse(date);
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
		formatter.
		System.out.println(date);
		
		
		

	}

}
