import java.util.Scanner;


public class Account2 {
	double bal,wd;
	void withdraw(double d)
	{
		if(bal>d){
			bal -=d;
		}
		else{
			System.out.println("no sufficient funds");
		}
		System.out.println(bal);
	}

}
class S_account2 extends Account2{
	final double min_bal=500;
	
	void withdraw(double d){
		if(bal>=wd){
			bal -=wd;
			if(bal>=min_bal){
				System.out.println(wd+"withdraw succesful");
			}
			else{
				System.out.println("min bal need to be maintained");
			}
		}
		else{
			System.out.println("no sufficient funds");
		}
	}
	
	
}
class C_account2 extends S_account2{
	boolean ov_draft;
	S_account2 sc = new C_account2();
	void withdraw(double d){
		if(bal>=wd){
			bal -=wd;
			if(bal>min_bal){
				
				ov_draft=false;
				System.out.println(ov_draft);
			}
			else{
				ov_draft= true;
				System.out.println(ov_draft);
			}
			
		}
		else{
			System.out.println("no sufficient funds");
		}
	}
	public static void main(String args[]){
		Scanner in = new Scanner(System.in);
		
		
		
		
		
	}
	
}
