package person4;

public class Person {
String name;
float age;
public void set_person(String n,float ag){
	//System.out.println("enter name");
	name=n;
	//System.out.println("enter age");
	age=ag;
}
public void get_person(){
	System.out.println("personal details: ");
	System.out.println(name+ " "+age);
}
}
