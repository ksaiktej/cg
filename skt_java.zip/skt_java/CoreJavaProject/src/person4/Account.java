package person4;

import java.util.Random;
import java.util.Scanner;

public class Account {
	long accnum;
	double balance;
    Person accHolder;
    //double amount;
	
	Account(long acn,double bal,Person accH){
		Random r = new Random();
		
		accnum = acn;
		balance = bal;
		accHolder = accH;
	}
	void dis_account(){
		System.out.println(accnum +" "+balance+" ");
		accHolder.get_person();
		}
	void deposit(double d){
		balance += d;
	}
	void withdraw(double w){
		balance-=w;
	}
	void display(){
		System.out.println("balance :"+balance);
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("enter personal details");
		Person accHolder = new Person();
		accHolder.set_person(sc.next(),sc.nextFloat());
		System.out.println("enter bank details");
		

		Account ac = new Account(sc.nextLong(),sc.nextDouble(),accHolder);
		ac.dis_account();
		while(true){
		System.out.println("select an option");
		System.out.println("1. deposit");
		System.out.println("2. withdraw");
		System.out.println("3. view balance");
		

		switch(sc.nextInt()){
		case 1:System.out.println("deposit amount");
			ac.deposit(sc.nextDouble());
			break;
		case 2:System.out.println("withdraw amount");
		ac.withdraw(sc.nextDouble());
		break;
		case 3:System.out.println("balance details");
		ac.display();
		break;
		
		
		}
		//sc.close();
		}
		

	} 

}
