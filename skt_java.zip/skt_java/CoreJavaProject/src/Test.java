
public class Test {
	
		
	    
public static void main(String args[]){

	try {
		return;
	} finally{
		// TODO: handle exception
		
	}
	}
		
		}


