package com.capgemini.contactbook.dao.test;
import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;





import com.capgemini.contactbook.dao.ContactBookDao;
import com.capgemini.contactbook.dao.ContactBookDaoImpl;
import com.capgemini.contactbook.exception.ContactBookException;
import com.igate.contactbook.bean.EnquiryBean;

public class ContactBookDaoImplTest {
	

	

		ContactBookDao dao = null;

		@Before
		public void setUp() {
			dao = new ContactBookDaoImpl();
		}

		@After
		public void tearDown() {
			dao = null;
		}

		@Test
		public void testAddEnquiry() {

			EnquiryBean enqry = new EnquiryBean();
			enqry.setContactNo("7036407471");
			enqry.setfName("SaiKrishnaTej");
			enqry.setlName("Kotipalli");
			enqry.setpDomain("JavaDeveloper");
			enqry.setpLocation("Hyderabad");
			

			try {
				Integer id = dao.addEnquiry(enqry);
				assertNotNull(id);

			} catch (ContactBookException e) {
				e.printStackTrace();
			}

		}

		
		

	}



