package com.capgemini.contactbook.dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import com.capgemini.contactbook.utility.JdbcUtility;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.capgemini.contactbook.exception.ContactBookException;

import com.igate.contactbook.bean.EnquiryBean;

public class ContactBookDaoImpl implements ContactBookDao {

	static Logger log = Logger.getLogger(ContactBookDaoImpl.class);
	Connection con = null;
	PreparedStatement ps = null;
	
	
	@Override
	public int addEnquiry(EnquiryBean enqry) throws ContactBookException {
		
		log.info("in add Patient Details method..");
		con = JdbcUtility.getConnection();
		
		try {
			
			ps = con.prepareStatement(QueryConstants.insertQuery);
			ps.setString(1, enqry.getfName());
			ps.setString(2, enqry.getlName());
			ps.setLong(3, Long.parseLong(enqry.getContactNo()));
			ps.setString(4, enqry.getpDomain());
			ps.setString(5, enqry.getpLocation());

			int r = ps.executeUpdate();

			ps = con.prepareStatement(QueryConstants.getIdQuery);
			ResultSet rs = ps.executeQuery();
			rs.next();
			int enqryId = rs.getInt(1);
			return enqryId;

		} catch (SQLException e) {
			
			log.error("statement not created");
             throw new ContactBookException("statement not created");
		}
	}

	@Override
	public EnquiryBean getEnquiryDetails(int enqryId) throws ContactBookException {
		log.info("In get enquiry details  method");
		
		con = JdbcUtility.getConnection();
		try {
			ps = con.prepareStatement(QueryConstants.getDetails);
			ps.setInt(1, enqryId);
			ResultSet resultSet=null;
			
			resultSet = ps.executeQuery();
				
			resultSet.next();
			EnquiryBean eb1 = new EnquiryBean();

			eb1.setEnqryId(resultSet.getInt(1));
			eb1.setfName(resultSet.getString(2));
			eb1.setlName(resultSet.getString(3));
			eb1.setContactNo(Long.toString(resultSet.getLong(4)));
			eb1.setpDomain(resultSet.getString(5));
			eb1.setpLocation(resultSet.getString(6));

			return eb1;
		} catch (SQLException e) {
			
			log.error("In get enquiry details method exception is: " + e.getMessage());
			throw new ContactBookException("sorry no details found");
		}
	}
}
