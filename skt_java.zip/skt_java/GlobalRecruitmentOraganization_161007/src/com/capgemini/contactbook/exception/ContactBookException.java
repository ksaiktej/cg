package com.capgemini.contactbook.exception;

public class ContactBookException extends Exception {

	private String exception;

	public ContactBookException(String exception) {
		super();
		this.exception = exception;
	}

	public String getException() {
		return exception;
	}
	
}
