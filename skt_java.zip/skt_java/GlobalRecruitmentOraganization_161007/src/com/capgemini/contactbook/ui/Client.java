package com.capgemini.contactbook.ui;

import java.util.InputMismatchException;
import java.util.Scanner;
import com.igate.contactbook.bean.EnquiryBean;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import com.capgemini.contactbook.service.ContactBookService;
import com.capgemini.contactbook.exception.ContactBookException;

import com.capgemini.contactbook.service.ContactBookServiceImpl;


public class Client {

	static Logger log = Logger.getLogger(Client.class);

	
	
	public static void main(String[] args) throws ContactBookException {

		Scanner sc = new Scanner(System.in);
		EnquiryBean enqry;
		ContactBookService service = new ContactBookServiceImpl();
		PropertyConfigurator.configure("resources/log4j.properties");
		log.info("log4j file loaded...");

		System.out.println("***************Global Recruitments***************");
		System.out.println("Choose an operation");
		System.out.println("1.Enter Enquiry Details");
		System.out.println("2.View Enquiry on Id");
		System.out.println("0.Exit");

		System.out.print("Please Enter a choice: ");
		int option = 0;

		try {
			option = sc.nextInt();
		} catch (InputMismatchException e) {
			System.err.println("Enter only digits");
		}
		
		
		switch (option) {
		case 1:
			sc.nextLine();
			
			enqry = new EnquiryBean();
			
			System.out.print("Enter firstName: ");
			
			String firstName = sc.nextLine();

			System.out.print("Enter lastName: ");
			
			String lastName = sc.nextLine();

			System.out.print("Enter contactNo: ");
			
			String contactNo = null;
			try {
				contactNo = sc.nextLine();
			} catch (InputMismatchException e) {
				
				System.out.print("Contact number should be digits only");
			}

			System.out.print("Enter Preferred Domain: ");
			String preferredDomain = sc.nextLine();

			System.out.print("Enter Preferred Location: ");
			String preferredLocation = sc.nextLine();

			enqry.setfName(firstName);
			enqry.setlName(lastName);
			enqry.setContactNo(contactNo);
			enqry.setpDomain(preferredDomain);
			enqry.setpLocation(preferredLocation);

			try {
				boolean result = service.isValidEnquiry(enqry);

				if (result) {
					int enqryId = service.addEnquiry(enqry);
					System.out.println("Thank you: " + enqry.getfName() + " " + enqry.getlName() + " your unique id is:"+ enqryId);
				}
			} catch (ContactBookException e) {
				System.err.println(e.getException());
			}
			
			break;
			
			
		case 2:
			
			System.out.print("Enter the Enquiry No: ");
			int enqryId = 0;
			try {
				enqryId = sc.nextInt();
			} catch (InputMismatchException e) {
				System.out.println("enter only digits");
			}
			try {
				enqry = service.getEnquiryDetails(enqryId);
				System.out.println(enqry);

			} catch (ContactBookException e) {

				System.err.println(e.getException());
			}
			
			break;
			
			
		case 0:
			
			System.out.println("Thank you selecting us!!");
			System.exit(0);
			break;
			
			
		default:
			
			break;
		}
}
}
