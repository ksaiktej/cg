package com.capgemini.contactbook.services;

import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.exceptions.ContactBookException;

public class ContactBookServiceImpl implements ContactBookService{

	@Override
	public int addEnquiry(EnquiryBean enqry) throws ContactBookException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public EnquiryBean getEnquiryDetails(int EnquiryID)
			throws ContactBookException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isValidEnquiry(EnquiryBean enqry)
			throws ContactBookException {
		// TODO Auto-generated method stub
		return false;
	}

}
