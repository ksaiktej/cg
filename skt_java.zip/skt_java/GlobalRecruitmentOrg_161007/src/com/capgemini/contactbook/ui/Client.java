package com.capgemini.contactbook.ui;

import java.util.InputMismatchException;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.dao.ContactBookDao;
import com.capgemini.contactbook.exceptions.ContactBookException;
import com.capgemini.contactbook.services.ContactBookServiceImpl;
import com.capgemini.contactbook.services.ContactBookService;
import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.services.ContactBookServiceImpl;
import com.capgemini.contactbook.services.ContactBookService;


public class Client {
	static Logger logger = Logger.getLogger(Client.class);
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		PropertyConfigurator.configure("resources/log4j.properties");
		logger.info("log4j file loaded...");
		Scanner scanner = new Scanner(System.in);
		ContactBookService service = new ContactBookServiceImpl();
		ContactBookService bookService = new ContactBookServiceImpl();
		System.out.println("****Global recuritments ***********");
		System.out.println("choose an option");
		System.out.println("1. Enter Enquiry details");
		System.out.println("2. View Enquiry deetails");
		System.out.println("0. Exit");
		System.out.println("please enter a choice");
		int choice = 0;
		try {
			choice = scanner.nextInt();
		} catch (InputMismatchException e) {
			System.out.println("enter only digits");
			System.exit(0);
		}
	//	EnquiryBean bean = new EnquiryBean();
		switch (choice) {
		case 1:
			scanner.nextLine();
			System.out.println("Enter first Name: ");
			String fName =scanner.nextLine();
			System.out.println("Neter Last Name: ");
			String lName = scanner.nextLine();
			System.out.println("enter contact number");
			String contactNo = scanner.nextLine();
			System.out.println("enter preferred Domain");
			String pDomain = scanner.nextLine();
			System.out.println("enter preferred location");
			String pLocation = scanner.nextLine();
			EnquiryBean enqry = new EnquiryBean();
			enqry.setfName(fName);
			enqry.setlName(lName);
			enqry.setContactNo(contactNo);
			enqry.setpDomain(pDomain);
			enqry.setpLocation(pLocation);
			
			try {
				boolean result = service.isValidEnquiry(enqry);
				if(result){
					int enqryId = service.addEnquiry(enqry);
					System.out.println("Thank you"+fName+lName+" your Unique Id is "+enqryId+" we will contact yu shortly");
				}
			} catch (ContactBookException e) {
				System.err.println(e.getMessage());
			}
			
			
			
			break;
		case 2:
			System.out.println("Enter Enquiry NO: ");
			int enqryid = scanner.nextInt();
			
	
			break;

		default:
			break;
		}
		

	}

}
