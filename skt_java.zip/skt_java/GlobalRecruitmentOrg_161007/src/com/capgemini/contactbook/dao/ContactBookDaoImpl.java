package com.capgemini.contactbook.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import org.apache.log4j.Logger;

import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.exceptions.ContactBookException;
import com.capgemini.contactbook.utility.JdbcUtility;

public class ContactBookDaoImpl implements ContactBookDao{
	static Logger logger = Logger.getLogger(ContactBookDaoImpl.class);
	Connection connection = null;
	PreparedStatement statement = null;
	

	@Override
	public int addEnquiry(EnquiryBean enqry) throws ContactBookException {
		// TODO Auto-generated method stub
		logger.info("in fix appoiment method..");
		
		return 0;
	}

	@Override
	public EnquiryBean getEnquiryDetails(int EnquiryID)
			throws ContactBookException {
		// TODO Auto-generated method stub
		return null;
	}

}
