package com.cg.ems.DAO;

public interface EmployeeDAO {

}
