package com.cg.ems.DAO;

public class EmployeeDAOImpl implements EmployeeDAO {

}
