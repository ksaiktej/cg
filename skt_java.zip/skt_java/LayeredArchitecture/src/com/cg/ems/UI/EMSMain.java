package com.cg.ems.UI;

import java.util.InputMismatchException;
import java.util.Scanner;

import com.cg.ems.DTO.Employee;
import com.cg.ems.Service.EmployeeService;
import com.cg.ems.Service.EmployeeServiceImpl;

public class EMSMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EmployeeService service = new EmployeeServiceImpl();
		System.out.println("Employee Management System");
		System.out.println("1. Add Employee]");
		System.out.println("2. Exit");
		Scanner sc = new Scanner(System.in);
		System.out.println("enter your choice");
		int option =0;
		try{
			option = sc.nextInt();
		}catch(InputMismatchException e){
			System.out.println("please enter numbers only");
			System.exit(0);
		}
		switch(option){
		case 1:
			System.out.println("enter Id");
			int id = sc.nextInt();
			System.out.println();
			System.out.println("enter name");
			String name = sc.nextLine();
			System.out.println("enter sal");
			double salary = sc.nextDouble();
			Employee employee = new Employee(id,name,salary);
			break;
		case 2: 
			System.out.println("Thank you visit again");
			System.exit(0);
			break;
		default:
			System.out.println("Invalid option");
			break;
		}

	}

}
