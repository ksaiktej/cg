package com.cg.ems.Service;

public interface EmployeeService {

}
