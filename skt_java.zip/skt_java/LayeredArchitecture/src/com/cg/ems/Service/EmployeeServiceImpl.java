package com.cg.ems.Service;

public class EmployeeServiceImpl implements EmployeeService {

}
