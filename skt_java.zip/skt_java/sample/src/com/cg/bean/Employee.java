package com.cg.bean;
import java.util.Scanner;
public class Employee {
	public static void main(String args[]){
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your option");
		System.out.println("1. Employee Details");
		System.out.println("2. Exit");
		int n = sc.nextInt();
		switch(n){
		case 1:
			System.out.println("Enter employee name");
			String ename = sc.next();
			System.out.println("Enter emp phno");
			int phno = sc.nextInt();
			System.out.println("enter emp role");
			String role = sc.next();
			System.out.println("enter sal");
			System.out.println("enter email id");
			String email = sc.next();
			System.out.println("registered succesfully");
			break;
		case 2:
			System.out.println("exit");
			break;
		}
		sc.close();
		System.exit(0);
		System.out.println("not executes");
	}
}
