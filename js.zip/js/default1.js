let firstname;
let lastname;
let User = {
set first(fname){
	
	this.firstname = fname;
	
},
set last(lname){
this.lastname = lname;
},
get fullname() {
return this.firstname + " "+ this.lastname;
}

}

User.first = "sai";
User.last = "kotipalli";

document.write(User.fullname);