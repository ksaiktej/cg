let firstname;
let lastname;
let User = {
set fullname(fname){
	let name = fname.split(" ");
	this.firstname = name[0];
	this.lastname = name[1];
},
get fullname() {
return this.firstname + " "+ this.lastname;
}
}
User.fullname = "sai kotipalli";

document.write(User.fullname);