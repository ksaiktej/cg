var person = {
name: 
};
document.write(person.name[1]);
document.write(person);