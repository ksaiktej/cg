let person = {
name: 'vijay',
display(){

document.writeln(this.name);
}
}
let employee = {
salary : 99000,
print(){

super.display();
document.writeln("your salary :" +this.salary);
document.write("<br>");
}
}

employee.__proto__= person;
employee.print();
//employee.display();

var emp = {id: 1, name: 'saikrishnatej', city:'hyderabad'}
var json = JSON.stringify(emp);
document.write(json);