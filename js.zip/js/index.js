let firstname;
let lastname;
let Customer = {
display(){
alert("this is customer class method display");
}
}
//let c = new Customer(); //dont explicitly create object for a class because it itself acts as an object
Customer.display();
function User(){}
User.prototype.sayHello = ()=> {  //arriw function withour parametres
alert("this is User method say Hello without params");
}

User.prototype.sayHello = (message) => {
alert(message);
}

/* //same like above
function sayHello(message){
alert(message);
}
*/

var u = new User();
u.sayHello();


let Student = {
firstname: 'sai',
lastname: 'kotipalli',


};
function st_dis();
Student.prototype.stdisplay = () => {
document.writeln("first name: "+Student.firstname);
document.writeln("Last name: "+Student.lastname);
}
var s = new st_dis();
s.stdisplay();

