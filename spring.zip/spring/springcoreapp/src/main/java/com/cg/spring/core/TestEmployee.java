package com.cg.spring.core;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestEmployee {

	public static void main(String[] args) {
		ConfigurableApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
		
		Employee e1 = (Employee) context.getBean("emp"); // casting method to inject bean class with bean Name
		
		System.out.println(e1);
		
		Manager manager = context.getBean(Manager.class); //inject bean through class
		/*manager.setDeptno(121);
		manager.setProjectCode("12345S1");
		manager.setProjectName("Top-Up");*/
		System.out.println(manager);
		context.close();
	}

}
