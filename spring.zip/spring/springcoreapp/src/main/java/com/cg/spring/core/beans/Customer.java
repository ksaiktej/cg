package com.cg.spring.core.beans;

import java.util.List;
import java.util.Map;
import java.util.Set;

public class Customer {
	//private String name;
	private String firstName;
	private String lastName;
	private Address addr;
	List<Address> list;
	Set<Address>set;
	Map<Integer, Address>map;
	
	
	public Map<Integer, Address> getMap() {
		return map;
	}
	public void setMap(Map<Integer, Address> map) {
		this.map = map;
	}
	public Set<Address> getSet() {
		return set;
	}
	public void setSet(Set<Address> set) {
		this.set = set;
	}
	public List<Address> getList() {
		return list;
	}
	public void setList(List<Address> list) {
		this.list = list;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public Address getAddr() {
		return addr;
	}
	public void setAddr(Address addr) {
		this.addr = addr;
	}
	
	public Customer(String firstName, String lastName, Address addr) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.addr = addr;
	}
	public Customer() {
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Customer [firstName=" + firstName + ", lastName=" + lastName + ", addr=" + addr + ", list=" + list
				+ ", set=" + set + ", map=" + map + "]";
	}
	
	
	

}
