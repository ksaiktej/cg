package com.cg.spring.mvc.repository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.cg.spring.mvc.beans.Product;
@Component  //it is my bean telling to annotations
public class ProductRepoImpl implements IproductRepo{
List<Product> list = new ArrayList();
	public List<Product> getAllProducts() {
		Product p1 = new Product();
		p1.setId(list.size() + 1);
		p1.setName("Iphone 6s");
		p1.setPrice(9800);
		list.add(p1);
		Product p2 = new Product();
		p2.setId(list.size() + 1);
		p2.setName("samsung galaxy s4");
		p2.setPrice(8900);
		list.add(p2);
		return list;
	}
	public void add(Product p) {
		
		Product p1 = new Product();
		/*p1.setId(list.size() + 1);
		p1.setName("Iphone 6s");
		p1.setPrice(9800);
		list.add(p1);
		Product p2 = new Product();
		p2.setId(list.size() + 1);
		p2.setName("samsung galaxy s4");
		p2.setPrice(8900);
		list.add(p2);*/
		p.setId(list.size() + 1);
		list.add(p);
	}
	public Product searchById(int id) {
		for(Product p: list) {
			if(p.getId()==id) {
				return p;
			}
		}
		return null;
	}

}
