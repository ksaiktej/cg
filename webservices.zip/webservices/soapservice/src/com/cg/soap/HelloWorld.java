package com.cg.soap;

import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.jws.soap.SOAPBinding.Style;
//want to provide service to Users through this interface
@WebService
@SOAPBinding(style = Style.DOCUMENT)
public interface HelloWorld {
	public String sayHello();
	

}
