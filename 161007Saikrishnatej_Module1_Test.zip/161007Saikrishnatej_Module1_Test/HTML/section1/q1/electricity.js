function valid(){
    var cno=document.getElementById('cno').value;
    var cname=document.getElementById('cname').value;
    var cmail=document.getElementById('cmail').value;
    var cnu=document.getElementById('cnu').value;
    var charges=0;
    if(cnu>100){
        charges = 5.56*cnu;
        alert(cno+" "+cname+" "+cmail+" "+cnu+" "+charges);
 
    } else {
        
            charges = 2.96*cnu;
            alert(cno+" -- "+cname+" -- "+cmail+" -- "+cnu+" -- "+charges);
     
        } 
     
    }
 
   